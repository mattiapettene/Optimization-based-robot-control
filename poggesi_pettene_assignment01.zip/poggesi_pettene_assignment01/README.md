Optimization- based robot control project - Poggesi Gabriele, Pettene Mattia

Configuration files legend:

h1_conf_1.py = first question, SQUAT = 0, PUSH = 0 
h1_conf_2.py = second question, SQUAT = 1, PUSH = 0, w_squat = 100 
h1_conf_2_bis.py = second question, SQUAT = 1, PUSH = 0, kp_squat = 100 
h1_conf_3.py = third question, SQUAT = 0, PUSH = 1, kp_squat = 100 
h1_conf_4.py = fourth question, SQUAT = 1, PUSH = 1, w_squat = 100, kp_squat = 100, push_robot_com_vel = [0, 0, -0,5] 
h1_conf_4_bis.py = fourth question, SQUAT = 1, PUSH = 1, w_squat = 10, kp_squat = 1000, push_robot_com_vel = [0, 0, -0,5] 

All the files have the following tuned weights: w_com = 40, w_foot = 50, w_posture = 4 

